package other;

@FunctionalInterface		// →  함수형 인터페이스인지 검사하는 메서드
public interface USB {
	void run();
}
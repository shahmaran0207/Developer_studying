package test;

public class EX01 {
	public static void main(String[] args) {
		System.out.println("Hello World!!");
	}
}

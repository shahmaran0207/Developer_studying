package _order;
//1. inherited
//└other

//2. object
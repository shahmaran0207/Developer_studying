package output;

public class EX02 {
	public static void main(String[] args) {
		System.out.println("Hello World !!");
		System.out.println("안녕 자바!");
		
		System.out.println("코드 위에서 아래로 순차적으로 수행");
		
		System.out.println("빈 줄은 실행하지 않는 줄이다.");
		
		
	}
}

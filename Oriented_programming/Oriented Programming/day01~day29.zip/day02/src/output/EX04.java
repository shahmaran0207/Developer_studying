package output; //package: 관련있는 클래스끼리 묶어서 관리하는 것
					// - 실제 위치한 패키지 명과 다르면 에러 발생함

public class EX04 { //class: 객체를 표현하는 것
						// - 실제 (.java)파일과 이름이 다르면 에러가 발생함
	
	public static void main(String[] args) {
		//main: 프로그램 제일 처음 실행되는 부분
		
		System.out.println("파일명을 변경 시 파일을 선택 후 F2를 눌러 바꿀 수 있다");
	}
}

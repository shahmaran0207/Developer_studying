package output;

public class Quiz {
/*
	1. main 함수 작성
	2. 그 안에 출력문을 작성하여 아래 결과를 똑같이 콘솔에 출력
	
	결과) 
	이름: 홍길동, 남
	나이: 27세
	신장: 174.5cm
	주소: 부산 광역시 해운대구 센텀 우2동
*/
	
	public static void main(String[] args) {
		System.out.printf("이름: %s, %s", "홍길동", "남");
		System.out.println();
		
		System.out.printf("나이: %d세", 27);
		System.out.println();
		
		System.out.printf("신장: %.1fcm", 174.5);
		System.out.println();
		
		System.out.println("주소: 부산광역시 해운대구 센텀 우2동");
	}
}

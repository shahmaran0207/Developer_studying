package output;

//주석: 컴파일 시 해석하지 않는 부분. 즉, 실행X
// 슬래시 2개 뒤 부터, 한줄 끝까지 적용

public class EX01 {

	//main 함수:  프로그램 실행 시 제일 처음 시작되는 영역
	public static void main(String[] args) {
		System.out.println("Hello Java!!");

		//ctrl+F11: 컴파일 후 실행
		//컴파일: 컴퓨터는 기계어를 모름 --> 기계어로 만든 후 실행

	}

}
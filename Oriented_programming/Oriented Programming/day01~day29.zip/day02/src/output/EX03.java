package output;

//ctrl + space: eclipse 자동완성

public class EX03 {
	public static void main(String[] args) {
		System.out.println("println()는 데이터를 콘솔에 출력하는 함수");
		
		//※함수는 '기능'이라고 생각하면 됨
		System.out.println("System이라는 자바에서 유용한 기본 기능을 제공하는 클래스");
		System.out.println("그 중 out은 표준 출력을 지원하는 객체");
	}
}

package _order;

//패키지 작성 순서
	//1. output
	//2. variable
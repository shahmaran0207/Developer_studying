package _order;
//1. array
//2. method
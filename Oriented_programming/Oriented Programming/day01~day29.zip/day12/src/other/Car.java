package other;

class Car {}

class Airplain{}

/*
	package크래스는 외부 패키지에서 import 불가능
	import 자체가 불가능하기 때문에 .java파일과 이름이 같을 필요 없음
	따라서 package클래스는 한 파일에 여러개 작성이 가능함
 */
package other;

public class Animal {}

//public class Machine{}
/*
	public 클래스를 import 시
	.class 파일의 이름으로 찾게 된다.
	따라서, public 클래스는 .java 파일명과 같아야 함
	
	파일 이름은 2가지를 가질 수 없으므로 
	public 클래스는 파일 당 1개만 선언 가능
*/